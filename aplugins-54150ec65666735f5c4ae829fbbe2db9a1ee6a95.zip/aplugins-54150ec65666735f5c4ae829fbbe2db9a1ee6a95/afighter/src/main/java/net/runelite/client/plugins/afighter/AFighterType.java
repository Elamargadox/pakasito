package net.runelite.client.plugins.afighter;

public enum AFighterType {
 NORMAL,
    BLUE_DRAGONS;
}
