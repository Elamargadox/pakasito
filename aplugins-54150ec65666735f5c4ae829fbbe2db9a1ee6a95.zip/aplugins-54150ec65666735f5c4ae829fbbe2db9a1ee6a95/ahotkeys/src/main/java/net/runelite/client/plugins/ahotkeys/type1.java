package net.runelite.client.plugins.ahotkeys;

public enum type1 {
    OBJECT,
    WALL,
    NPC,
    WIDGET,
    WALK,
    INVENTORY_ITEM
}
