package net.runelite.client.plugins.abankstander;

public enum ABankStanderBarType {
	Molten_Glass,
	Bronze,
	Iron,
	Steel,
	Gold,
	Mithril,
	Adamant,
	Rune;
}
