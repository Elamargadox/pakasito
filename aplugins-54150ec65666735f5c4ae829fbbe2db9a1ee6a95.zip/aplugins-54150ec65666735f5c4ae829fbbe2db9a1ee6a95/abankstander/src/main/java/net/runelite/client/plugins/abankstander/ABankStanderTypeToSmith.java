package net.runelite.client.plugins.abankstander;

public enum ABankStanderTypeToSmith {
	DART_TIPS,
	BOLTS,
	PLATELEGS,
	PLATESKIRT,
	PLATEBODY,
	TWOHAND_SWORD,
	LIMBS;
}
