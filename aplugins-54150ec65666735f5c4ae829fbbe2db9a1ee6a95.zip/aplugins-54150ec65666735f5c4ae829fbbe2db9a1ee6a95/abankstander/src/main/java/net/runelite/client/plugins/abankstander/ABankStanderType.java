package net.runelite.client.plugins.abankstander;

public enum ABankStanderType {
    Fletcher,
    Crafter,
    COOKER,
    COOK_KARAMBWANS,
    SMELTER,
    SMITHER,
    HERB_CLEANER,

    HIGH_ALCHER,

    SAWMILL_PLANKS,
    STRING_BOWS
}
