package net.runelite.client.plugins.abankstander;

public enum ABankStanderTypeFletching {
SHORTBOWS,
    LONBOWS,
    STOCKS,
    SHIELDS
}
