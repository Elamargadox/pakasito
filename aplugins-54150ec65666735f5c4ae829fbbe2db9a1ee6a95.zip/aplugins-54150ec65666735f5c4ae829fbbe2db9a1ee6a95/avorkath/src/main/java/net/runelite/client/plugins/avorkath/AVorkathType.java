package net.runelite.client.plugins.avorkath;

public enum AVorkathType {

	VORKATH

}
