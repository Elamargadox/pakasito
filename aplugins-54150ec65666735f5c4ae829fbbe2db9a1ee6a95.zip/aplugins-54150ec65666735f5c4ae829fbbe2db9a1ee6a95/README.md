# Anarchise' OpenOSRS Plugins
Vorkath Zulrah and Rune Dragons newly added to the plugin repo!

# How to use:

First, add my github repository to OpenOSRS:
Owner: anarchise
Repository: aplugins
Then install plugins via external plugin manager.

# Alternatively:

Go to the releases tab and download the .jar files that you require
Then navigate to C:/Users/YOURUSERHERE/.openosrs/plugins and paste the .jars 

# Discord Server:
https://discord.com/invite/KwJnhKQJVc
 OR to contact me privatel, Anarchise#7778

