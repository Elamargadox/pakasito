package net.runelite.client.plugins.autils;

import java.util.List;
import net.runelite.api.coords.WorldPoint;

class Outer
{
	public List<WorldPoint> path;
}