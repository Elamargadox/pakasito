package net.runelite.client.plugins.pestcontrol;

public enum PestControlState {
	ANIMATING,
	MOVING,
	TIMEOUT,
	PLAY_GAME,
	ENTER_LOBBY,

}
