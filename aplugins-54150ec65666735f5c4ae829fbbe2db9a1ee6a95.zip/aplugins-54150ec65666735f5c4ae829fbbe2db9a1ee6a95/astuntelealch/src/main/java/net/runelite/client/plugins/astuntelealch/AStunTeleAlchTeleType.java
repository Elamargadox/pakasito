package net.runelite.client.plugins.astuntelealch;

public enum AStunTeleAlchTeleType {

    VARROCK,
    LUMBRIDGE,
    FALADOR,
    HOUSE,
    CAMELOT,
    ARDOUGNE,
    WATCHTOWER,
    TROLLHEIM,
    APE_ATOLL,
    KOUREND
}
