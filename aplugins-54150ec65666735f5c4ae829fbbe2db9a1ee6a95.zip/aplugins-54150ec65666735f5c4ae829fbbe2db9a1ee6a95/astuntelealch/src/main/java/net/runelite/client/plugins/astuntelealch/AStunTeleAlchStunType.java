package net.runelite.client.plugins.astuntelealch;

public enum AStunTeleAlchStunType {
    CONFUSE,
    WEAKEN,
    CURSE,
    VULNERABILITY,
    ENFEEBLE,
    STUN
}
