package net.runelite.client.plugins.astuntelealch;

public enum AStunTeleAlchType {
    TELEPORTER,
    STUN
}
