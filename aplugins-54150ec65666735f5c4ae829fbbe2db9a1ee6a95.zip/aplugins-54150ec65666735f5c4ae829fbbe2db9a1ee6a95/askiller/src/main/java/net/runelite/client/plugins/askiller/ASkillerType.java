package net.runelite.client.plugins.askiller;

public enum ASkillerType {
    NPC,
    GAME_OBJECT,
    WALL_OBJECT,
    DENSE_ESSENCE
}
