package net.runelite.client.plugins.arcer;

public enum ARcerRuneType
{
	MINE_ESS_VARROCK,
	AIR_RUNE,
	WATER_RUNE,
	EARTH_RUNE,
	FIRE_RUNE,
	COSMIC_RUNE,
	LAW_RUNE,
	BODY_RUNE,
	NATURE_RUNE_ABYSS,
	ZEAH_BLOOD_RUNE;
}
