package net.runelite.client.plugins.arcer;

public enum ARcerType
{
	COMBINATION_RUNES,
	RUNES;
}
